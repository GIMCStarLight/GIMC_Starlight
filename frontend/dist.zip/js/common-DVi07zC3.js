const n="Loading menu",a={loadingMenu:n};export{a as default,n as loadingMenu};
