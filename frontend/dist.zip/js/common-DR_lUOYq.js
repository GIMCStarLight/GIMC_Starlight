const a="正在加载菜单",e={loadingMenu:a};export{e as default,a as loadingMenu};
